Name: Mohammed Rushad
Roll Number: 181CO232

Accuracies Obtained: (Implemented in Rapid Miner on Iris Dataset)

id3: 94.67%
C4.5: 95.33%
CART: 94.67%