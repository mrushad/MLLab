Name: Mohammed Rushad
Roll Number: 181CO232

This folder contains the submission for the Machine learning lab midsem.

KNN model applied on the Wisconsin Cancer Dataset.

Accuracy obtained: 93.56% for k=7 neighbors.