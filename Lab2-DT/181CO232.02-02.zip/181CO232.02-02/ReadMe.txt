Name: Mohammed Rushad
Roll Number: 181CO232

This floder contains the application of the Decision Tree Algorithm (id3, C4.5, CART) on the Pima Indians Diabetes dataset.
Pruning has also been applied.
Id3 and CART are done in Python3, and C4.5 in Rapidminer.

Accuracies:
ID3 - 77.05%
C4.5 - 73.56%
CART - 75.75%