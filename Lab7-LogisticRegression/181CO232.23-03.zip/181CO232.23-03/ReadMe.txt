Name: Mohammed Rushad
Roll Number: 181CO232
Date: 23/03/2021

This folder contains the submissions for the lab for Logistic Regression.
The implementation was done in a Google Colab Notebook.
The Logistic Regression model was built on the Pima Indians Diabetes Dataset.
Screenshot for various Errors and Score and Accuracy have been included.