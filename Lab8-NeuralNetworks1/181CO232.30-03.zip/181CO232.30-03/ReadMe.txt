Name: Mohammed Rushad
Roll Number: 181CO232

This folder contains the notebook and screenshots for the ANN implementation of AND Gate done using keras.

Accuracy obtained: 100%