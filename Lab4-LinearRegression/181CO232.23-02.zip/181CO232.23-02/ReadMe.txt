Name: Mohammed Rushad
Roll Number: 181CO232

This folder contains the submissions for the lab for Linear Regression.
The implementation was done in a Google Colab Notebook.
The model was built on the Red Wine Quality Dataset.
Screenshot for various Errors and Score have been included.