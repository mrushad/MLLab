Name: Mohammed Rushad
Roll Number: 181CO232
Date: 16/03/2021

This folder contains the submissions for the lab for Support vector Machine and K Nearest Neighbors(KNN).
The implementation was done in a Google Colab Notebook.
Support Vector Machine model was built on the Digits dataset of images.
K Nearest Neighbors model was built on the Credit dataset.
Screenshot for various Errors and Score and Accuracy have been included.