Name: Mohammed Rushad
Roll Number: 181CO232

This floder contains the application of the Naive Bayesian Classifier on the Pima Indians Diabetes dataset.
The implementation was done in a Google Colab Notebook.
Screenshots of Accuracy, Confusion Matrix and Classification Report on the testing data have been included.

Accuracy obtained: 78%